﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ProjetoMedicamento.View {
    class MedicamentosView {

        //Atributos
        Medicamentos meds;

        public MedicamentosView() {
            Console.Write("" +
                " ------------------------------\n" +
                "      Projeto Medicamentos\n" +
                " ------------------------------\n");
            meds = new Medicamentos();
            Thread.Sleep(1250);
        }

        public void menu() {

            Console.Clear();
            Console.Write("" +
                " Menu\n" +
                " 0. Finalizar Processo\n" +
                " 1. Cadastrar Medicamento\n" +
                " 2. Consultar Medicamento (sintetico)\n" +
                " 3. Consultar Medicamento (analitico)\n" +
                " 4. Comprar Medicamento\n" +
                " 5. Vender Medicamento\n" +
                " 6. Listar Medicamentos\n" +
                " Escolha uma opção: "
            );
            Int32 opcao = 0;
            try {
                opcao = Convert.ToInt32(Console.ReadLine());
            } catch (Exception) {
                menu();
            }

            switch (opcao) {
                case 1:
                    Console.Write("" +
                    " ---------------------------------\n" +
                    "      Adicionar Medicamento\n" +
                    " ---------------------------------\n" +
                    " Digite o nome do medicamento: ");
                    string nomeMed = Console.ReadLine();
                    Console.Write(" Digite o nome do laboratório: ");
                    string nomeLab = Console.ReadLine();
                    try {
                        meds.adicionar(new Medicamento(
                            meds.getMedsListCount(),
                            nomeMed,
                            nomeLab,
                            new Queue<Lote>()
                        ));
                        Console.WriteLine(" Adicionado.");
                    }
                    catch (Exception) {
                        Console.WriteLine(" Ocorreu um erro ao adicionar o objeto.");
                    }
                    Thread.Sleep(1250);
                    break;
                case 2:
                    Console.Write("" +
                    " ---------------------------------\n" +
                    " Consultar Medicamento (Sintético)\n" +
                    " ---------------------------------\n" +
                    " Digite o identificador do medicamento: ");
                    pesquisarMedicamento(Convert.ToInt32(Console.ReadLine()));
                    Console.WriteLine("\n Pressione qualquer tecla para continuar...");
                    Console.ReadKey();
                    break;
                case 3:
                    Console.Write("" +
                    " ---------------------------------\n" +
                    " Consultar Medicamento (Analítico)\n" +
                    " ---------------------------------\n" +
                    " Digite o identificador do medicamento: ");
                    Int32 idAnalitico = Convert.ToInt32(Console.ReadLine());
                    pesquisarMedicamento(idAnalitico);
                    pesquisarMedicamentoAnalitico(idAnalitico);
                    Console.WriteLine("\n Pressione qualquer tecla para continuar...");
                    Console.ReadKey();
                    break;
                case 4:
                    Console.Write("" +
                    " ---------------------------------\n" +
                    "      comprar Medicamento\n" +
                    " ---------------------------------\n" +
                    " Digite o identificador do medicamento: ");
                    Int32 idMedCompra = Convert.ToInt32(Console.ReadLine());
                    try {
                        Console.Write(" Digite a quantidade a ser comprada: ");
                        Int32 quant = Convert.ToInt32(Console.ReadLine());
                        Console.Write(" Digite a data de vencimento ( formato: dd/mm/yyyy ): ");
                        DateTime dtVenc = Convert.ToDateTime(Console.ReadLine());

                        meds.ListaMedicamentos[idMedCompra].comprar(new Lote(
                            meds.ListaMedicamentos[idMedCompra].getLoteCount(),
                            quant,
                            dtVenc
                        ));
                        Console.WriteLine(" Adicionado.");
                        Thread.Sleep(1250);

                    } catch (Exception) {
                        Console.WriteLine(" Ocorreu um erro no processamento.");
                        Thread.Sleep(1250);
                    }
                    break;
                case 5:
                    Console.Write("" +
                    " ---------------------------------\n" +
                    "       Vender Medicamento\n" +
                    " ---------------------------------\n" +
                    " Digite o identificador do medicamento: ");
                    Int32 idMedVenda = Convert.ToInt32(Console.ReadLine());
                    try {
                        Console.Write(" Quantidade de unidades vendidas: ");
                        Int32 quantVend = Convert.ToInt32(Console.ReadLine());
                        if (meds.ListaMedicamentos[idMedVenda].vender(quantVend)) {
                            Console.WriteLine(" Vendido.");
                        } else {
                            Console.WriteLine(" Aviso: A quantidade informada é maior que a quantidade disponível.");
                        }
                        Int32 quantRestante = 0;
                        foreach (Lote lote in meds.ListaMedicamentos[idMedVenda].Lotes) {
                            quantRestante += lote.Quantidade;
                        }
                        if (quantRestante <= 0) {
                            meds.deletar(meds.ListaMedicamentos[idMedVenda]);
                        }
                    } catch (Exception) {
                        Console.WriteLine(" Ocorreu um erro no processamento");
                    };
                    
                    Thread.Sleep(1250);
                    break;
                case 6:
                    Console.Write("" +
                    " ---------------------------------\n" +
                    "       Listar Medicamentos\n" +
                    " ---------------------------------"
                    );
                    foreach (Medicamento med in meds.ListaMedicamentos) {
                        pesquisarMedicamento(med.Id);
                    }
                    Console.WriteLine("\n Pressione qualquer tecla para continuar...");
                    Console.ReadKey();
                    break;
                default:
                    System.Environment.Exit(0);
                    break;
            }

            menu();
        }

        public void pesquisarMedicamento(Int32 idSintetico) {
            try {
                Medicamento medPesquisado = meds.pesquisar(new Medicamento(idSintetico, null, null, null));
                if (medPesquisado != null) {
                    Console.Write("\n" +
                        " Medicamento encontrado: \n" +
                        medPesquisado.toString() +
                       "\n ----------------------------------------------"
                    );
                } else {
                    Console.Write(" Medicamento não foi encontrado.\n");
                    Thread.Sleep(1250);
                }
            }
            catch (Exception) {
                Console.WriteLine(" Ocorreu um erro de processamento.");
                Thread.Sleep(1250);
            }
        }

        public void pesquisarMedicamentoAnalitico(Int32 idAnalitico) {
            try {
                Medicamento medPesquisado = meds.pesquisar(new Medicamento(idAnalitico, null, null, null));
                if (medPesquisado != null) {
                    foreach (Lote lote in medPesquisado.Lotes) {
                        Console.Write("\n Lote " + lote.Id + "\n" +
                            "     Quantidade: " + lote.Quantidade + "\n" +
                            "     Vencimento: " + lote.Vencimento + "\n");
                    }
                    
                }
            } catch (Exception) {
            
            }
        }
    }
}
