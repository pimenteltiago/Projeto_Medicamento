﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoMedicamento {
    class Medicamento {

        //Atributos
        private int id;
        private string nome;
        private string laboratorio;
        private Queue<Lote> lotes;

        //Construtor
        public Medicamento() {
            
        }
        public Medicamento(int id, string nome, string laboratorio, Queue<Lote> lotes) {
            this.id = id;
            this.nome = nome;
            this.laboratorio = laboratorio;
            this.lotes = lotes;
        }

        //Metodos
        public int quantidadeDisponivel() {
            int varQtDisponivel = 0;
            foreach (Lote lote in lotes) {
                varQtDisponivel += lote.Quantidade;
            }
            return varQtDisponivel;
        }
        public void comprar(Lote lote) {
            lotes.Enqueue(lote);
        }
        public bool vender(int qt) {
            if (qt == 0) {
                return false;
            }
            /*Partindo do principio que os lotes estão ordenados pela
              data de vencimento em ordem crescrente.*/
            foreach (Lote lote in lotes) {
                if (lote.Quantidade < qt) {
                    qt -= lote.Quantidade;
                    lotes.Dequeue();
                } else {
                    Int32 qtTemp = qt;
                    lote.Quantidade -= qt;
                    qt -= qtTemp;
                }
            }
            if (qt > 0) {
                return false;
            }
            return true;
        }
        public string toString() {
            return " Id: " + id + "\n" +
                " Nome: " + nome + "\n" +
                " Laboratorio: " + laboratorio + "\n" +
                " Quantidade Disp.: " + quantidadeDisponivel();
        }
        private bool equals(object obj) {

            return false;
        }

        public Int32 getLoteCount() {
            return lotes.Count;
        }

        //Getters e Setters
        public int Id { get => id; set => id = value; }
        internal Queue<Lote> Lotes { get => lotes; set => lotes = value; }
    }
}
