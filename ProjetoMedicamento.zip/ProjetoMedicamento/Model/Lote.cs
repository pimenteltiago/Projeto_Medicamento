﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoMedicamento {
    class Lote {

        //Atributos
        private int id;
        private int quantidade;
        private DateTime vencimento;

        //Construtor
        public Lote() { 
        
        }
        public Lote(int id, int quantidade, DateTime vencimento) {
            this.id = id;
            this.quantidade = quantidade;
            this.vencimento = vencimento;
        }

        //Metodos
        public string toString() {
            return " Id:" + id + "\n" +
                "Quantidade: " + quantidade + "\n" +
                "Vencimento: " + vencimento;
        }

        //Getters e Setters
        public int Quantidade { get => quantidade; set => quantidade = value; }
        public DateTime Vencimento { get => vencimento; set => vencimento = value; }
        public int Id { get => id; set => id = value; }
    }
}
