﻿using System;

namespace ProjetoMedicamento {
    class Program {
        static void Main(string[] args) {

            View.MedicamentosView vm = new View.MedicamentosView();
            vm.menu();
        }
    }
}
