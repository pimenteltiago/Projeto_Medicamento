﻿using System;
using System.Collections.Generic;
using System.Text;


namespace ProjetoMedicamento {
    class Medicamentos {

        //Atributos
        private List<Medicamento> listaMedicamentos;

        //Construtor
        public Medicamentos() {
            listaMedicamentos = new List<Medicamento>();
        }

        //Metodos
        public void adicionar(Medicamento medicamento) {
            listaMedicamentos.Add(medicamento);
        }
        public bool deletar(Medicamento medicamento) {
            try {
                listaMedicamentos.Remove(medicamento);
                return true;
            } catch (Exception) {
                return false;
            }
        }
        public Medicamento pesquisar(Medicamento med) {
            foreach (Medicamento medDaLista in listaMedicamentos) {
                if (med.Id == medDaLista.Id) {
                    return medDaLista;
                }
            }
            return null;
        }

        public int getMedsListCount() {
            return listaMedicamentos.Count;
        }

        //Getters e Setters
        internal List<Medicamento> ListaMedicamentos { get => listaMedicamentos; set => listaMedicamentos = value; }
    }
}
